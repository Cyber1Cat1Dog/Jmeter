/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 92.33385483980682, "KoPercent": 7.666145160193184};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.904221586181997, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9748446400828586, 500, 1500, "GET /characters"], "isController": false}, {"data": [0.9796109833769391, 500, 1500, "DELETE /character/id"], "isController": false}, {"data": [0.6090714992449097, 500, 1500, "GET /character/id"], "isController": false}, {"data": [0.9800031553206595, 500, 1500, "PUT /character/id"], "isController": false}, {"data": [0.9794070701520265, 500, 1500, "POST /character"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 191113, 14651, 7.666145160193184, 302.0671121273873, 0, 5987, 297.0, 308.0, 310.0, 314.0, 3173.0006143016058, 10314.148617017192, 559.3018636063655], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /characters", 38620, 134, 0.3469704816157431, 317.6288969445893, 0, 5987, 297.0, 310.0, 316.0, 946.0, 641.208699983397, 9603.17419293749, 78.89872675576956], "isController": false}, {"data": ["DELETE /character/id", 37839, 0, 0.0, 302.29424667670986, 0, 1742, 297.0, 310.0, 316.0, 949.0, 628.8891104906262, 179.94580993530616, 133.8721144597211], "isController": false}, {"data": ["GET /character/id", 38406, 14517, 37.798781440399935, 290.0296828620534, 0, 1741, 297.0, 309.0, 315.0, 945.9900000000016, 637.9840196681008, 186.34030465622354, 80.08631723014503], "isController": false}, {"data": ["PUT /character/id", 38031, 0, 0.0, 301.59122820856567, 0, 1751, 297.0, 310.0, 315.0, 950.0, 632.2167733355499, 172.9829613342615, 137.1738081570526], "isController": false}, {"data": ["POST /character", 38217, 0, 0.0, 298.68686710102816, 0, 1730, 297.0, 309.0, 315.0, 951.0, 634.8760714997675, 172.47049936353744, 129.70323959959964], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 2,326 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,945 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 2,814 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,706 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 3,265 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,831 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,056 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,063 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,514 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,255 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,700 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,688 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,690 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,309 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,313 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,147 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 3,355 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 2,413 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,210 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,198 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,287 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,427 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,431 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,472 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,844 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,259 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 3,211 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,888 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in path at index 33: http://localhost:3001/character/${characterId}%20", 1000, 6.825472663981981, 0.5232506422901634], "isController": false}, {"data": ["The operation lasted too long: It took 3,558 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,254 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,918 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,130 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,879 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,690 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 2,815 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,607 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,958 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,973 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 5,894 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,903 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,433 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,549 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,042 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,400 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,790 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,488 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,799 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,703 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,940 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,813 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,917 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,580 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,061 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,226 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,160 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,534 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,919 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,804 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,856 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,311 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,527 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,261 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,399 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,870 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,559 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,196 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,146 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,050 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,531 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 3,354 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,036 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,701 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,286 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 5,832 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,723 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,933 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,102 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,025 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 3,199 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,880 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 2,489 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,125 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,035 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["404/Not Found", 13517, 92.25991399904443, 7.0727789318361385], "isController": false}, {"data": ["The operation lasted too long: It took 2,825 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,543 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,606 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,805 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,864 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,922 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,305 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,871 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 3, 0.020476417991945942, 0.0015697519268704902], "isController": false}, {"data": ["The operation lasted too long: It took 5,987 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,902 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,401 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,359 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,039 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,120 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,791 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,905 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,693 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 2,592 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 3, 0.020476417991945942, 0.0015697519268704902], "isController": false}, {"data": ["The operation lasted too long: It took 4,536 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,254 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,702 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,552 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, 0.013650945327963961, 0.0010465012845803268], "isController": false}, {"data": ["The operation lasted too long: It took 2,689 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,918 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 3,251 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 2,318 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,920 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,904 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 4,540 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,043 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,054 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}, {"data": ["The operation lasted too long: It took 5,895 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 1, 0.0068254726639819805, 5.232506422901634E-4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 191113, 14651, "404/Not Found", 13517, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in path at index 33: http://localhost:3001/character/${characterId}%20", 1000, "The operation lasted too long: It took 5,871 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 3, "The operation lasted too long: It took 2,592 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 3, "The operation lasted too long: It took 5,945 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET /characters", 38620, 134, "The operation lasted too long: It took 5,871 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 3, "The operation lasted too long: It took 2,592 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 3, "The operation lasted too long: It took 5,945 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, "The operation lasted too long: It took 2,706 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2, "The operation lasted too long: It took 5,147 milliseconds, but should not have lasted longer than 2,000 milliseconds.", 2], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /character/id", 38406, 14517, "404/Not Found", 13517, "Non HTTP response code: java.net.URISyntaxException/Non HTTP response message: Illegal character in path at index 33: http://localhost:3001/character/${characterId}%20", 1000, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
